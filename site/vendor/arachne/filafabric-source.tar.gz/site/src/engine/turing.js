import { createRng } from './rng.js';
import { contourLoops } from './spiral.js';
import { clipPolyline, densify, appendPoints } from './layers.js';
import { backingStack, carrierLayers } from './backing.js';
import { attachMotifs, cellSeed } from './repair-geometry.js';
import { ConfigError } from './params.js';

/**
 * Turing stripes: the iso-lines of a Gray-Scott reaction-diffusion field, the same chemistry that makes animal
 * stripes and coral. The field is grown on a grid from a few seeded specks until it settles into worms and
 * stripes about one wavelength apart, then its mid-level contour is traced as closed loops (layer 1). An independent
 * hatch across them (layer 2) crosses every stripe. The same seed always grows the same pattern.
 */

// feed and kill rates in the labyrinth regime: long winding stripes rather than spots
const DU = 0.16, DV = 0.08, FEED = 0.037, KILL = 0.06;

/** Grows the field: returns { data, nx, ny, cell } with v in about 0..0.5, over a grid with a border of bare cells. */
export function growField(box, { wavelength = 7, seed = 1, steps = 3500, legacy=false } = {}) {
  const w = box.maxX - box.minX, h = box.maxY - box.minY;
  // about nine cells per wavelength; never more than 150 cells on a side
  const cell = Math.max(wavelength / 9, Math.max(w, h) / 150);
  const nx = Math.ceil(w / cell) + 4, ny = Math.ceil(h / cell) + 4;
  const rng = createRng(seed);
  let u = new Float32Array(nx * ny).fill(1);
  let v = new Float32Array(nx * ny);
  const specks = Math.max(6, Math.round((nx * ny) / 200));
  for (let k = 0; legacy && k < specks; k++) {
    const cx = 4 + Math.floor(rng.next() * (nx - 8)), cy = 4 + Math.floor(rng.next() * (ny - 8));
    for (let dy = -2; dy <= 2; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        u[(cy + dy) * nx + cx + dx] = 0.5;
        v[(cy + dy) * nx + cx + dx] = 0.25 + 0.05 * rng.next();
      }
    }
  }
  if(!legacy){
    // Gray–Scott specks need a contiguous nucleus; isolated single cells diffuse away.
    // Anchor nuclei to coarse world-grid cells, not to the cropped outline or iteration order.
    const originX=Math.floor(box.minX/cell)-2,originY=Math.floor(box.minY/cell)-2,stride=12;
    for(let gy=Math.floor(originY/stride);gy<=Math.floor((originY+ny)/stride);gy++)for(let gx=Math.floor(originX/stride);gx<=Math.floor((originX+nx)/stride);gx++){
      const random=createRng(cellSeed(seed,gx,gy));
      const cx=gx*stride+3+Math.floor(random.next()*6)-originX,cy=gy*stride+3+Math.floor(random.next()*6)-originY;
      for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){
        const x=cx+dx,y=cy+dy;
        if(x<1||x>=nx-1||y<1||y>=ny-1)continue;
        u[y*nx+x]=.5;v[y*nx+x]=.25+.05*random.next();
      }
    }
  }
  let u2 = new Float32Array(nx * ny);
  let v2 = new Float32Array(nx * ny);
  for (let s = 0; s < steps; s++) {
    for (let y = 1; y < ny - 1; y++) {
      for (let x = 1; x < nx - 1; x++) {
        const i = y * nx + x;
        const lu = u[i - 1] + u[i + 1] + u[i - nx] + u[i + nx] - 4 * u[i];
        const lv = v[i - 1] + v[i + 1] + v[i - nx] + v[i + nx] - 4 * v[i];
        const uvv = u[i] * v[i] * v[i];
        u2[i] = u[i] + DU * lu - uvv + FEED * (1 - u[i]);
        v2[i] = v[i] + DV * lv + uvv - (FEED + KILL) * v[i];
      }
    }
    [u, u2] = [u2, u];
    [v, v2] = [v2, v];
  }
  // the border ring stays bare so every contour closes inside the grid
  for (let x = 0; x < nx; x++) { v[x] = 0; v[(ny - 1) * nx + x] = 0; }
  for (let y = 0; y < ny; y++) { v[y * nx] = 0; v[y * nx + nx - 1] = 0; }
  return { data: v, nx, ny, cell, minX: box.minX - 2 * cell, minY: box.minY - 2 * cell };
}

/** Joins closed loops into strands: each strand carries on into the nearest loop whose start is within `jog`. */
function chainLoops(loops, boundary, jog) {
  const left = loops.map((l) => l.slice(0, -1));
  const strands = [];
  let cur = null;
  while (left.length) {
    let pick = 0, at = 0, best = Infinity;
    const ref = cur ? cur[cur.length - 1] : left[0][0];
    left.forEach((loop, li) => {
      for (let i = 0; i < loop.length; i++) {
        const d = Math.hypot(loop[i].x - ref.x, loop[i].y - ref.y);
        if (d < best) { best = d; pick = li; at = i; }
      }
    });
    const loop = left.splice(pick, 1)[0];
    const rotated = [...loop.slice(at), ...loop.slice(0, at)];
    rotated.push({ ...rotated[0] });
    if (cur && best <= jog && boundary.contains((rotated[0].x + ref.x) / 2, (rotated[0].y + ref.y) / 2)) {
      appendPoints(cur, densify([ref, rotated[0]]), 1);
      appendPoints(cur, rotated, 1);
    } else {
      if (cur) strands.push(cur);
      cur = rotated;
    }
  }
  if (cur) strands.push(cur);
  return strands;
}

/**
 * @param wavelength  distance between neighbouring stripes (mm)
 * @param seed        which pattern grows
 * @param angle       angle of the hatch laid across it, degrees
 * @param spacing     spacing of the hatch, mm
 */
export function turingLayers(boundary, { wavelength = 7, seed = 1, angle = 45, spacing = 5, backing = 'straight', backingDepth = 2, backingLength = 10, backingLayers = 'one', whole = true, support = null, bead=.45, legacy=false, bleed = 0 } = {}) {
  const box = boundary.bbox();
  // `bleed` grows the field past the swatch edge, so the stripes run to the edge and the edge cuts them
  const field = growField(bleed ? { minX: box.minX - bleed, minY: box.minY - bleed, maxX: box.maxX + bleed, maxY: box.maxY + bleed } : box, { wavelength, seed, legacy });
  let max = 0;
  for (const value of field.data) if (value > max) max = value;
  if (whole && max > 0) {
    // whole stripes (repeats.js): the field fades to bare over the last third of a wavelength inside the edge, so a
    // stripe that runs to the edge closes there in a rounded end instead of being cut off by it
    const keep = 0.5, ramp = wavelength / 3;
    for (let j = 0; j < field.ny; j++) {
      for (let i = 0; i < field.nx; i++) {
        const x = field.minX + i * field.cell, y = field.minY + j * field.cell;
        const d = Math.min(x - box.minX, box.maxX - x, y - box.minY, box.maxY - y) - keep;
        const t = Math.max(0, Math.min(1, d / ramp));
        field.data[j * field.nx + i] *= t * t * (3 - 2 * t);
      }
    }
  }
  const loops = max > 0.05 ? contourLoops({ ...field, max }, max / 2).filter((l) => l.length > 8) : [];
  const strands = chainLoops(loops, boundary, wavelength * 1.2);
  const layer1 = strands.flatMap((s) => clipPolyline(s, boundary));
  const stack = support ? carrierLayers(boundary, support) : backingStack(boundary, { style: backing, angle, spacing, depth: backingDepth, wavelength: backingLength }, backingLayers);
  // the flat card is the stripes alone, to be backed later: nothing to attach them to
  if(legacy||bleed)return {layers:[layer1,...stack],extra:{loops:loops.length}};
  const attached=attachMotifs(layer1,stack,boundary,{bead,reach:Math.max(wavelength,spacing)*4,merge:true});
  if(attached.unattached)throw new ConfigError([`${attached.unattached} long Turing fragments cannot reach two carrier contacts inside the outline. Use a denser or crossed two-layer Support carrier.`]);
  return {layers:[attached.paths,...stack],extra:{loops:loops.length,attachment:{dropped:attached.dropped,extended:attached.extended,unattached:attached.unattached}},warnings:attached.dropped||attached.extended?[`Carrier attachment: ${attached.dropped} stripe fragments dropped, ${attached.extended} extended.`]:[]};
}
