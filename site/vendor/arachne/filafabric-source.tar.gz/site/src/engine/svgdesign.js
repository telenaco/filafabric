import { PolygonBoundary } from './boundary.js';
import { densify, clipPolyline } from './layers.js';
import { windowRings } from './window.js';
import { finishAtPrintedBoundary } from './fabric.js';
import { infillLines, INFILL_IDS } from './infill.js';
import { classifyPaths, interpretDrawing, linePassesDetailed } from './drawing.js';
import { carrierLayers } from './backing.js';

/**
 * Drawing & infill (the card's id is 'svgdesign'): a drawing becomes a printable textile, its red shapes filled with a
 * slicer infill pattern, with one or two backing layers on top.
 *
 *  - The design layer is the drawing itself, read the way drawing.js says: closed RED shapes are filled with a slicer
 *    infill pattern, closed BLUE shapes are holes (blue inside red cuts a hole, red inside that is filled again), and
 *    everything else is a line, printed with as many passes as its width asks for. The drawing's lines as drawn
 *    (outline), its red areas filled (fill), or both.
 *  - Each backing layer is one more layer of a slicer infill pattern, over the whole swatch, over the drawn shapes
 *    only, or over the drawing's bounding box. A backing line rides over the design lines wherever it crosses one,
 *    so the layers are held together by the crossings and nothing needs gluing.
 *
 * Everything here is plain geometry (polylines in mm): printing, crossing lifts, ties and the report are the shared
 * layered pipeline's job.
 */

export const DESIGN_MODES = Object.freeze(['outline', 'fill', 'both']);
export const BACKING_COUNTS = Object.freeze(['none', 'one', 'two']);
export const BACKING_AREAS = Object.freeze(['swatch', 'shape', 'box']);

const countOf = (backing) => (backing === 'two' ? 2 : backing === 'one' ? 1 : 0);

const circle = (cx, cy, r, n = 48) => {
  const pts = Array.from({ length: n }, (_, i) => ({ x: cx + r * Math.cos((2 * Math.PI * i) / n), y: cy + r * Math.sin((2 * Math.PI * i) / n) }));
  return [...pts, { ...pts[0] }];
};

/** A drawing to start from: a red heart with a blue ring cut out of it and a black stem joining the ring to the tip. In a 100 x 100 mm box. */
export function sampleVector() {
  const n = 120;
  const heart = Array.from({ length: n }, (_, i) => {
    const t = (2 * Math.PI * i) / n;
    const x = 16 * Math.sin(t) ** 3;
    const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
    return { x: 50 + x * 2.55, y: 10 + (y + 17) * 2.55 };
  });
  heart.push({ ...heart[0] });
  return {
    name: 'Sample heart',
    width: 100,
    height: 100,
    paths: [heart, circle(50, 58, 11), [{ x: 50, y: 47 }, { x: 50, y: 35 }, { x: 50, y: 22 }, { x: 50, y: 11 }]],
    styles: [{ color: 'red', width: 0.25 }, { color: 'blue', width: 0.25 }, { color: 'other', width: 0.45 }],
  };
}

/** The drawing's paths scaled to a width x height swatch, as closed rings and open strokes (colours ignored). */
export function splitPaths(vector, width, height) {
  const sx = width / vector.width, sy = height / vector.height;
  return classifyPaths(vector.paths.map((path) => path.map((p) => ({ x: p.x * sx, y: p.y * sy }))));
}

const bboxOf = (paths) => {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const path of paths) for (const p of path) {
    if (p.x < minX) minX = p.x;
    if (p.x > maxX) maxX = p.x;
    if (p.y < minY) minY = p.y;
    if (p.y > maxY) maxY = p.y;
  }
  return Number.isFinite(minX) ? { minX, minY, maxX, maxY } : null;
};

/**
 * @param boundary  the swatch (or outline) as a boundary
 * @param settings  { width, height, mode, designPattern, designSpacing, designAngle, backing ('none' | 'one' | 'two'),
 *                    backingArea, backing1Pattern, backing1Spacing, backing1Angle, backing2Pattern, … }
 * @param vector    { name, width, height, paths, styles? } in mm, or null for the sample drawing
 * @param options   { bead } the width of one printed line, which sets how many passes a wide line takes
 * @returns { layers, extra, warnings }: layers of polylines (the design, then each backing), ready for layeredResult
 */
export function svgDesignLayers(boundary, settings, vector = null, { bead = 0.45, vectorSize = null, vectorOffset = [0, 0], includeLines = true, onlyLayer = null } = {}) {
  const s = settings;
  const source = vector ?? sampleVector();
  const [fw, fh] = vectorSize ?? [s.width, s.height], [ox, oy] = vectorOffset;
  const sx = fw / source.width, sy = fh / source.height;
  const projected = { ...source, paths: source.paths.map((pts) => pts.map((p) => ({ x: p.x * sx - ox, y: p.y * sy - oy }))), styles: source.styles?.map((style) => ({ ...style, width: style.width * Math.sqrt(sx * sy) })) };
  const model = interpretDrawing(projected);
  const warnings = [];
  let mode = s.mode;
  if ((mode === 'fill' || mode === 'both') && model.fills.length === 0) {
    const who = vector ? vector.name : 'The drawing';
    warnings.push(model.styled
      ? `${who} has no red closed shape to fill (a closed shape is filled when it is red; blue is left empty), so its lines print as drawn`
      : `${who} has no closed shapes to fill, so its lines print as drawn`);
    mode = 'outline';
  }

  // the edge of every red or blue shape, and every line with its passes
  const cropLines = (pts) => clipPolyline(pts, boundary, 0);
  const edges = includeLines && (onlyLayer === null || onlyLayer === 0) ? model.shapes.flatMap((sh) => cropLines([...sh.ring, { ...sh.ring[0] }])) : [];
  let droppedPasses = 0;
  const lines = includeLines && (onlyLayer === null || onlyLayer === 0) ? model.lines.flatMap((line) => {
    const detail = linePassesDetailed(line, bead, { align: s.lineAlign ?? 'centre', spacing: s.passSpacing ?? .8 });
    droppedPasses += detail.dropped;
    return detail.passes;
  }).flatMap(cropLines) : [];
  if (droppedPasses) warnings.push(`${droppedPasses} passes did not fit inside small shapes.`);
  const outlines = [...edges, ...lines];
  const rings = windowRings(model.rings, s.width, s.height);
  const shape = rings.length ? new PolygonBoundary(rings) : null;
  const design = [];
  if (mode === 'outline' || mode === 'both') design.push(...outlines);
  if ((onlyLayer === null || onlyLayer === 0) && (mode === 'fill' || mode === 'both') && shape) {
    // in 'both' the fill stops at the outline's own line; in 'fill' it forms the shape's edge by itself
    let fill = infillLines(s.designPattern, shape, { spacing: s.designSpacing, angle: s.designAngle, layer: 0, inset: mode === 'both' ? 0.15 : 0.25 });
    if (mode === 'both') fill = finishAtPrintedBoundary(fill.map((pts) => ({ pts })), new PolygonBoundary(model.rings), bead).map((s) => s.pts);
    design.push(...fill);
    // lines are not shapes, so a fill never draws them: keep them printed as lines
    if (mode === 'fill') design.push(...lines);
  }

  const all = [...model.rings, ...model.lines.map((l) => l.pts)];
  const box = bboxOf(all);
  const margin = 3;
  const areaFor = (kind) => {
    if (kind === 'shape' && model.rings.length) return shape;
    if (kind === 'box' || (kind === 'shape' && box)) {
      const b = box ?? boundary.bbox();
      const rect = [{ x: b.minX - margin, y: b.minY - margin }, { x: b.maxX + margin, y: b.minY - margin }, { x: b.maxX + margin, y: b.maxY + margin }, { x: b.minX - margin, y: b.maxY + margin }];
      const cropped = windowRings([rect], s.width, s.height);
      return cropped.length ? new PolygonBoundary(cropped) : null;
    }
    return boundary;
  };

  const layers = [design];
  const backing = [];
  const support = s.support;
  const n = support ? support.enabled === false ? 0 : support.layers : countOf(s.backing);
  const area = support?.area ?? s.backingArea;
  const region = areaFor(area);
  const carrier = support && region ? carrierLayers(region, support) : null;
  for (let k = 1; k <= n; k++) {
    const pass = support?.passes?.[k - 1];
    const pattern = support ? pass?.pattern ?? (support.style === 'straight' ? 'rectilinear' : support.style) : s[`backing${k}Pattern`];
    const spacing = support ? pass?.spacing ?? support.openness : s[`backing${k}Spacing`];
    const angle = support ? pass?.angle ?? support.angle + 90 * (k - 1) : s[`backing${k}Angle`];
    const lines = region && (onlyLayer === null || onlyLayer === k) ? carrier?.[k - 1] ?? infillLines(pattern, region, { spacing, angle, layer: k }) : [];
    // Keep existing family IDs for old snapshots; these passes are carriers, not native motifs.
    layers.push(Object.assign(lines, { family: `L${k + 1}`, role: 'carrier' }));
    backing.push({ pattern, spacing, angle, lines: lines.length });
  }
  if (area === 'shape' && !shape && n > 0) warnings.push('There are no closed shapes, so the backing covers the drawing\'s bounding box instead');

  return {
    layers,
    warnings,
    extra: {
      svgDesign: {
        name: source.name,
        sample: !vector,
        closed: model.shapes.length,
        open: model.lines.length,
        filled: model.fills.length,
        holes: new Set(model.fills.flatMap((f) => f.holes)).size,
        lines: model.lines.length,
        mode,
        designPattern: mode === 'outline' ? null : s.designPattern,
        backing,
      },
    },
  };
}

export { INFILL_IDS };
