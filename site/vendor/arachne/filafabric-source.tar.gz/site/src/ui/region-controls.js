import { el } from './dom.js';
import { colourBarModel, paletteName, REGION_PALETTE, lineLayersOf, LINE_LAYERS_MAX, lineWidthOf, colourName } from '../engine/regions.js';

const PAINTS = { red:'#ff0000',blue:'#0000ff',green:'#00ff00',yellow:'#ffff00',other:'#777777' };
const ROLE_LABELS = { pattern:'Pattern',hole:'Hole',solid:'Solid',line:'Line' };

/** Region navigation. Existing card panels remain the settings editor. */
const alignSelect=(value,onChange,label)=>{
  const select=el('select',{'aria-label':label},...[['inside','Inside the edge'],['centre','Centred on the edge'],['outside','Outside the edge']].map(([v,text])=>el('option',{value:v,text,selected:v===value})));
  select.addEventListener('change',()=>onChange(select.value));
  return el('label',{class:'field-row'},el('span',{text:label}),select);
};

export class RegionControls {
  constructor(options) { Object.assign(this, options); }

  update(regions, selection, seam) {
    this.bar.hidden = !regions?.length;
    this.header.hidden = !regions?.length;
    if (!regions?.length) { this.bar.replaceChildren(); this.header.replaceChildren(); return; }
    const active = document.activeElement;
    const focusId = this.bar.contains(active) ? active.dataset.regionFocus : null;
    // Colours first, as named in the drawing; lines together at the end. What a colour prints as is chosen below ("Print as").
    const model = colourBarModel(regions.map(r=>({...r,cardName:this.cards.find(c=>c.id===r.card)?.name})), selection)
      .sort((a,b)=>(a.role==='line')-(b.role==='line'));
    const applied = new Set(regions.filter(r=>r.applied).map(r=>r.id));
    // far left: tick or untick every colour at once
    const all = el('input',{type:'checkbox',checked:model.every(c=>c.enabled),'aria-label':'Tick every colour','data-region-focus':'all-enabled'});
    all.indeterminate = model.some(c=>c.enabled) && !model.every(c=>c.enabled);
    all.addEventListener('change',()=>this.change(null,{allEnabled:all.checked}));
    const allChip = el('span',{class:'region-chip region-all',title:'Tick or untick every colour'},el('label',{class:'region-enabled'},all));
    this.bar.replaceChildren(allChip,...model.map((chip,index)=>{
      const input = el('input',{type:'checkbox',checked:chip.enabled,'aria-label':`Include ${chip.label}`,'data-region-focus':`${chip.id}-enabled`});
      input.addEventListener('change',()=>this.change(chip.id,{enabled:input.checked}));
      const button = el('button',{type:'button',class:'region-select','aria-pressed':String(chip.selected),'aria-label':chip.label,title:chip.label,tabindex:chip.selected||!selection&&index===0?'0':'-1','data-region-focus':chip.id},
        el('span',{class:'region-paint',style:`background:${chip.hex??PAINTS[chip.color]}`,'aria-hidden':'true'}),...(chip.role==='line'?[el('span',{class:'small muted',text:'Line'})]:[]));
      button.addEventListener('click',()=>this.select(chip.id));
      button.addEventListener('keydown',event=>{
        if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
        event.preventDefault();
        const next=event.key==='Home'?0:event.key==='End'?model.length-1:(index+(event.key==='ArrowRight'?1:-1)+model.length)%model.length;
        this.select(model[next].id); this.bar.querySelector(`[data-region-focus="${model[next].id}"]`)?.focus();
      });
      if(applied.has(chip.id))button.append(el('span',{class:'region-applied',text:'✓',title:'Applied: part of the piece','aria-label':'applied'}));
      return el('span',{class:`region-chip${chip.enabled?'':' excluded'}${applied.has(chip.id)?' applied':''}`},el('label',{class:'region-enabled'},input),button);
    }));
    if(focusId)this.bar.querySelector(`[data-region-focus="${focusId}"]`)?.focus();
    const region=regions.find(r=>r.id===selection);
    const done=el('button',{type:'button',class:'link small',text:'Whole piece'}); done.addEventListener('click',this.close);
    if(!region){this.header.replaceChildren(el('h2',{class:'eyebrow',text:'Drawing regions'}),el('p',{class:'small muted',text:'Tick a colour and choose what it prints as. Apply sets it aside as part of the piece: untick it and it keeps showing while you work on the next colour on top of it.'}),el('p',{class:'small muted',text:`Draw in ${REGION_PALETTE.map(c=>c.name).join(', ')}. Red is the pattern, blue a hole, green and yellow solids; the others are lines.`}));return;}
    // choosing what an unticked colour prints as (or editing it) puts it in the piece: otherwise the change shows nothing
    const edit=(patch)=>this.change(region.id,region.enabled===false?{...patch,enabled:true}:patch);
    const role=el('select',{'aria-label':'Region role',id:'region-role'},...Object.entries(ROLE_LABELS).map(([value,text])=>el('option',{value,text,selected:value===region.role})));
    role.addEventListener('change',()=>edit({role:role.value}));
    const parts=[el('div',{class:'region-header-title'},el('span',{class:'region-paint',style:`background:${region.hex??PAINTS[region.color]}`}),el('strong',{text:`${colourName(region.hex)??region.color} ${region.hex??''}`}),done),el('label',{class:'field-row'},el('span',{text:'Print as'}),role)];
    if(region.enabled===false){
      const include=el('button',{type:'button',class:'link small',text:`Include ${colourName(region.hex)??region.color}`});
      include.addEventListener('click',()=>this.change(region.id,{enabled:true}));
      parts.push(el('p',{class:'small muted region-excluded-note'},`${colourName(region.hex)??region.color} is not in the preview yet: it is unticked in the colour row. `,include));
    }
    if(region.role==='pattern'){
      const picker=el('select',{id:'region-card','aria-label':'Design for this region'},...this.cards.filter(c=>c.status==='ready'&&!c.hidden).map(c=>el('option',{value:c.id,text:`${c.name} · ${c.shelf}`,selected:c.id===region.card})));
      picker.addEventListener('change',()=>this.useCard(region.id,picker.value));
      parts.push(el('label',{class:'field-row stacked'},el('span',{text:'Region design'}),picker),el('p',{class:'small muted',text:`The settings below apply to ${colourName(region.hex)??region.color} only.`}));
    }
    if(region.role==='line'){
      const layers=el('input',{type:'number',min:1,max:LINE_LAYERS_MAX,step:1,value:lineLayersOf(region),'aria-label':'Layers'});
      layers.addEventListener('change',()=>edit({lineLayers:lineLayersOf({lineLayers:layers.value})}));
      const thick=el('input',{type:'number',min:.2,max:20,step:.1,value:lineWidthOf(region)??'',placeholder:'as drawn','aria-label':'Thickness in mm'});
      thick.addEventListener('change',()=>edit({lineWidth:lineWidthOf({lineWidth:thick.value})}));
      parts.push(el('label',{class:'field-row'},el('span',{text:'Layers'}),layers),el('label',{class:'field-row'},el('span',{text:'Thickness mm'}),thick),
        alignSelect(region.lineAlign??'centre',value=>edit({lineAlign:value}),'Line sits'),
        el('p',{class:'small muted',text:'Thickness is the drawn line width unless you set one: the nozzle goes round as many times as it takes. Layers stacks it taller, for folds and stiffening.'}));
    }
    if(region.applied){
      const out=el('button',{type:'button',class:'link small',text:'Take out of the piece'});
      out.addEventListener('click',()=>this.change(region.id,{applied:false}));
      parts.push(el('p',{class:'small muted'},'Applied: this colour is part of the piece. ',out));
    }
    parts.push(el('p',{class:'small muted',text:seam.enabled?`Outline: ${seam.width} mm ${seam.align==='centre'?'centred on':seam.align} the edge of each colour, joining it to its neighbours. Change it under Size and shape.`:'No outline: the colours are not joined along their edges. Set one under Size and shape.'}));
    this.header.replaceChildren(...parts);
  }
}
