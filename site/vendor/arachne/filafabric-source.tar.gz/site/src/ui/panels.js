// The settings panel as classes.
//
// Every design's panel is assembled from the same few parts, so a change to one part (how a slider reads out, how the
// size is hidden when an SVG is imported, what an option button looks like) is a change in one class and applies to
// every design.
//
//   Control               anything that draws itself and can refresh itself from the current settings
//     SliderControl       one labelled slider whose read-out can be typed over
//     SizeControl         the width and height fields (hidden while an SVG sets the size)
//     PatternPicker       a grid of pattern fields and the room for a pattern-size slider
//     Section             a titled group of a design's panel, shown only while its `when(settings)` holds
//       PresetsSection, SizeSection, ShapeSection, ChoiceSection, SwitchSection, SlidersSection, PatternSection
//     DesignPanel         one design's whole panel, built from the `controls` its registry entry describes
//     SvgImportCard       the single place a drawing comes in: its lines, and optionally its shape as the outline
//
// The panel does not know the studio. It is given a `host`, an object with these methods:
//   binding(id)          { get(key), set(key, value), range(key), readout(key), size: { ranges, get(), set(w, h, preset) } }
//   settings(id)         the design's settings object, which sections read and write
//   change()             a setting changed what the design is: refresh every control, regenerate, save
//   nudge()              a slider moved: refresh the read-outs and regenerate (the save happens on release)
//   sizeChanged()        the size was typed: refresh and regenerate
//   commit()             save the state to the undo history
//   toast(message)       say something briefly
//   vectorSize()         [w, h] of the imported SVG, or null when none is imported
//   svg()                what the import card shows, see SvgImportCard
import { el, svgEl, helpBubble } from './dom.js';
import { validNumber } from './numeric.js';
import { FIELDS, createField } from '../engine/fields.js';
import { PICTURE } from '../engine/picture.js';
import { PATTERN_EFFECTS } from '../engine/pattern-effects.js';
import { SHAPES } from '../engine/shapes.js';
import { shapeThumb } from './thumbs.js';
import { SHELVES, variantsOf } from './library.js';
import { BACKING_STYLES } from '../engine/backing.js';
import { SAMPLERS } from '../engine/squiggle.js';
import { draftBinding, WEAVE_DRAFT_PRESETS } from '../engine/weave.js';
import { CARD_ESTIMATES } from './card-estimates.js';
import { estimateLine } from './estimate-line.js';

const fmt = (n) => String(Math.round(n * 10) / 10);

/** Base of everything in the panel: owns one DOM node, and refreshes it from the current settings. */
export class Control {
  constructor(host) {
    this.host = host;
    this.node = null;
  }

  /** Redraw from the current settings. The default does nothing. */
  update() {}

  /** Redraw what depends on the colour scheme (pictures drawn on a canvas). The default does nothing. */
  redraw() {}
}

/* ---------- single controls ---------- */

export class SliderControl extends Control {
  /** @param def { key, label, help, lo, hi, unit } as listed in a design's `sliders` group */
  constructor(host, designId, def) {
    super(host);
    this.designId = designId;
    this.def = def;
    this.inputId = `${designId}-${def.key}`;
    this.node = this.build();
  }

  get binding() {
    return this.host.binding(this.designId);
  }

  build() {
    const { def, binding } = this;
    const range = binding.range(def.key);
    this.input = el('input', { id: this.inputId, type: 'range', min: range.min, max: range.max, step: range.step, 'aria-describedby': `${this.inputId}-help` });
    this.input.value = String(binding.get(def.key));
    this.input.addEventListener('input', () => { binding.set(def.key, Number(this.input.value)); this.host.nudge(); });
    this.input.addEventListener('change', () => this.host.commit());
    this.warn = el('p', { class: 'ctl-warn small', hidden: true });
    this.readout = el('button', { type: 'button', class: 'ctl-readout editable', id: `${this.inputId}-out`, title: 'Click to type a value', 'aria-label': `${def.label}: type an exact value` });
    this.readout.addEventListener('click', () => this.edit());
    // the end labels say which way is which; the sentence of help is a tooltip on the label, and still read out
    return el('div', { class: 'ctl' },
      el('div', { class: 'ctl-top' }, el('span', { class: 'ctl-heading' },
        el('label', { class: 'ctl-label', for: this.inputId, text: def.label, 'data-tip': !def.info && def.help || false }),
        def.info && helpBubble(def.label, def.help)), this.readout),
      el('p', { class: 'ctl-help visually-hidden', id: `${this.inputId}-help`, text: def.help }),
      this.input,
      el('div', { class: 'ctl-ends', 'aria-hidden': 'true' }, el('span', { text: def.lo }), el('span', { text: def.hi })),
      this.warn);
  }

  /** Swap the read-out for a number field so an exact value can be typed; Enter or leaving applies it, Escape cancels. */
  edit() {
    const { def, binding, readout } = this;
    const range = binding.range(def.key);
    const field = el('input', { type: 'number', class: 'ctl-edit', step: 'any', inputmode: 'decimal', 'aria-label': `${def.label}${def.unit ? ` in ${def.unit}` : ''}` });
    field.value = String(binding.get(def.key));
    let done = false;
    const finish = (apply) => {
      if (done) return;
      done = true;
      const raw = field.value.trim();
      const n = Number(raw);
      if (apply && raw !== '' && Number.isFinite(n)) {
        if (!validNumber(def.key, n, range)) {
          this.host.toast(`${def.label}: enter a valid ${range.min === 0 ? 'non-negative' : 'positive'} value.`);
          field.replaceWith(readout);
          readout.focus();
          return;
        }
        binding.set(def.key, n);
        this.host.nudge();
        this.host.commit();
      }
      field.replaceWith(readout);
      this.update();
      readout.focus();
    };
    field.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
    });
    field.addEventListener('blur', () => finish(true));
    readout.replaceWith(field);
    field.focus();
    field.select();
  }

  update() {
    const { def, binding } = this;
    this.node.hidden = typeof def.when === 'function' ? !def.when(this.host.settings(this.designId)) : false;
    const available = binding.available?.(def.key) !== false;
    this.input.disabled = !available;
    this.readout.disabled = !available;
    if (document.activeElement !== this.input) this.input.value = String(binding.get(def.key));
    const text = binding.readout(def.key);
    this.input.setAttribute('aria-valuetext', text);
    this.readout.textContent = text;
    const r = binding.range(def.key);
    const manual = binding.get(def.key) < r.min || binding.get(def.key) > r.max;
    this.readout.classList.toggle('manual-value', manual);
    this.readout.title = manual ? 'Manual value outside the slider range. Click to edit.' : 'Click to type an exact value';
    // a typed value is used as typed; outside the range it only gets a warning
    this.warn.hidden = !manual;
    if (manual) this.warn.textContent = `${text} is outside the slider's usual range (${fmt(r.min)} to ${fmt(r.max)}). It is used as typed: lines may overlap or the print may not fit, so check the preview.`;
  }
}

/**
 * Width and height. While an SVG is imported the swatch is the SVG's own size, so the fields give way to a line
 * that says so: the same for every design, because every design builds its size from this class.
 */
export class SizeControl extends Control {
  constructor(host, designId) {
    super(host);
    this.designId = designId;
    const b = host.binding(designId).size;
    this.error = el('p', { class: 'field-error', id: `${designId}-size-error`, hidden: true });
    const make = (axis, label, range) => {
      const limit = host.sizeLimits?.(designId)?.[axis === 'w' ? 'width' : 'height'];
      const input = el('input', { id: `${designId}-${axis}`, type: 'number', inputmode: 'decimal', step: range.step, ...(limit !== undefined ? { max: limit } : {}) });
      const field = el('label', { class: 'size-field', for: input.id }, el('span', { class: 'size-label', text: label }), input, el('span', { class: 'unit', 'aria-hidden': 'true', text: 'mm' }));
      return { field, input, range, label: label.toLowerCase() };
    };
    this.width = make('w', 'Width', b.ranges.w);
    this.height = make('h', 'Height', b.ranges.h);
    const onInput = () => {
      for (const f of [this.width, this.height]) f.input.removeAttribute('aria-invalid');
      const bad = [this.width, this.height].find((f) => {
        const n = Number(f.input.value);
        return !f.input.value.trim() || !Number.isFinite(n) || n <= 0;
      });
      if (bad) {
        bad.input.setAttribute('aria-invalid', 'true');
        this.error.textContent = `Enter a ${bad.label} greater than 0 mm.`;
        this.error.hidden = false;
        this.host.sizeInvalid?.();
        return;
      }
      const limits = this.host.sizeLimits?.(this.designId);
      for (const [f, max] of [[this.width, limits?.width], [this.height, limits?.height]]) {
        if (max !== undefined && Number(f.input.value) > max) {
          f.input.setAttribute('aria-invalid', 'true');
          this.error.textContent = `The selected printer allows at most ${max} mm ${f.label}. This size has not been applied.`;
          this.error.hidden = false;
          this.host.sizeInvalid?.();
          return;
        }
      }
      this.error.hidden = true;
      b.set(Number(this.width.input.value), Number(this.height.input.value), null);
      this.host.sizeChanged();
    };
    for (const f of [this.width, this.height]) {
      f.input.addEventListener('input', onInput);
      f.input.addEventListener('change', () => this.host.commit());
    }
    this.inputs = el('div', { class: 'size-inputs' }, this.width.field, el('span', { class: 'times', 'aria-hidden': 'true', text: '×' }), this.height.field);
    this.note = el('p', { class: 'size-follows small muted', hidden: true });
    this.divider = el('div', { class: 'size-source-divider', text: 'or', 'aria-hidden': 'true' });
    this.svgSlot = el('div', { class: 'size-svg-slot' });
    this.brim = new SliderControl({ ...host, binding: () => host.binding('print') }, `${designId}-edge`, {
      key: 'brim', label: 'Solid perimeters', info: true, help: 'Walls inside solid shapes. More walls strengthen their edges; 0 leaves only infill. Mesh edges use the separate Mesh outlines setting.',
      lo: 'Off', hi: 'Wide', unit: 'lines', edit: true,
    });
    this.brim.node.classList.add('brim-control');
    this.meshPerimeters = new SliderControl({ ...host, binding: () => host.binding('print') }, `${designId}-mesh-edge`, {
      key: 'meshPerimeters', label: 'Mesh outlines', info: true, help: 'Extra rings around the mesh and inside pattern windows. They reinforce loose ends and add material. 0 leaves them off; solid shapes use Solid perimeters.',
      lo: 'Off', hi: 'Wide', unit: 'lines', edit: true,
    });
    this.meshPerimeters.node.classList.add('brim-control');
    this.warn = el('p', { class: 'ctl-warn small', hidden: true });
    this.node = el('div', { class: 'size-control' }, this.inputs, this.divider, this.svgSlot, this.note, this.warn, this.error, this.brim.node, this.meshPerimeters.node);
  }

  update() {
    this.brim.update();
    this.meshPerimeters.update();
    const limits = this.host.sizeLimits?.(this.designId);
    for (const [f, max] of [[this.width, limits?.width], [this.height, limits?.height]]) {
      if (max !== undefined) f.input.max = String(max);
    }
    const follow = this.host.vectorSize();
    this.inputs.hidden = !!follow;
    this.note.hidden = true;
    this.divider.hidden = !!follow;
    if (follow) {
      this.error.hidden = true;
      this.warn.hidden = true;
      return;
    }
    const [w, h] = this.host.binding(this.designId).size.get();
    for (const [f, v] of [[this.width, w], [this.height, h]]) {
      if (document.activeElement !== f.input && f.input.getAttribute('aria-invalid') !== 'true') f.input.value = String(v);
    }
    const outside = [[this.width, w], [this.height, h]].filter(([f, v]) => v < f.range.min || v > f.range.max);
    this.warn.hidden = outside.length === 0;
    if (outside.length) this.warn.textContent = `${outside.map(([f, v]) => `${f.label} ${fmt(v)} mm`).join(' and ')} is outside the usual control range. It is used as typed when it fits the selected printer; full-size preview is available.`;
  }
}

/** A heat map of a pattern field in the accent colour: bright where the field is high. */
function drawFieldThumb(canvas, field) {
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  const size = 48;
  canvas.width = size * ratio;
  canvas.height = size * ratio;
  const ctx = canvas.getContext('2d');
  ctx.scale(ratio, ratio);
  ctx.clearRect(0, 0, size, size);
  const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#34469a';
  if (field === 'none') {
    ctx.strokeStyle = accent;
    ctx.globalAlpha = 0.55;
    ctx.lineWidth = 2;
    for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(10 + i * 14, 24, 5, 0, Math.PI * 2); ctx.stroke(); }
    return;
  }
  const sampler = FIELDS[field] ? createField(field) : SAMPLERS[field];
  if (!sampler) return;
  const cells = 24;
  ctx.fillStyle = accent;
  for (let j = 0; j < cells; j++) {
    for (let i = 0; i < cells; i++) {
      ctx.globalAlpha = 0.08 + 0.92 * sampler(((i + 0.5) / cells) * 100, ((cells - j - 0.5) / cells) * 100, 100, 100);
      ctx.fillRect(i * 2, j * 2, 2, 2);
    }
  }
}

/* ---------- a long list of options behind one line ---------- */

/** A list with more options than this sits behind one line that names the chosen option. */
export const FOLD_AFTER = 4;

const CHEVRON = '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7l5 5 5-5"/></svg>';

/** The small pictures on section headers, so a closed panel can be read without reading its titles. */
const SECTION_ICONS = {
  presets: '<path d="M9 2.5l1.9 4 4.3.5-3.2 2.9.9 4.3L9 12l-3.9 2.2.9-4.3L2.8 7l4.3-.5z"/>',
  size: '<rect x="3" y="3" width="12" height="12" rx="2"/><path d="M7 3v2.5M11 3v2.5M3 7h2.5M3 11h2.5"/>',
  layers: '<path d="M9 3l6 3-6 3-6-3z"/><path d="M3 9.5l6 3 6-3M3 12.5l6 3 6-3"/>',
  sliders: '<path d="M3 5h7M13 5h2M3 13h2M8 13h7"/><circle cx="11.5" cy="5" r="1.6"/><circle cx="6.5" cy="13" r="1.6"/>',
  pattern: '<g fill="currentColor" stroke="none"><circle cx="4.5" cy="4.5" r="0.9"/><circle cx="9" cy="4.5" r="1.3"/><circle cx="13.5" cy="4.5" r="1.8"/><circle cx="4.5" cy="9" r="1.3"/><circle cx="9" cy="9" r="1.8"/><circle cx="13.5" cy="9" r="1.3"/><circle cx="4.5" cy="13.5" r="1.8"/><circle cx="9" cy="13.5" r="1.3"/><circle cx="13.5" cy="13.5" r="0.9"/></g>',
  shape: '<circle cx="6.5" cy="6.5" r="3.5"/><path d="M9.5 15.5l3-5.5 3 5.5z"/>',
  colour: '<path d="M9 2.5c3 3.6 4.5 6.2 4.5 8a4.5 4.5 0 01-9 0c0-1.8 1.5-4.4 4.5-8z"/>',
};

/** Which picture a section gets, from what kind of section it is or, for the hand-built panels, from its title. */
export function sectionIcon(title = '', kind = '') {
  const t = title.toLowerCase();
  if (kind === 'presets' || t.startsWith('start from')) return 'presets';
  if (kind === 'size' || t.includes('size')) return 'size';
  if (kind === 'pattern' || /pattern|grade|picture|turn with/.test(t)) return 'pattern';
  if (kind === 'sliders' || /look and feel|wave/.test(t)) return 'sliders';
  if (/layer|backing|structure/.test(t)) return 'layers';
  if (t.includes('colour')) return 'colour';
  return 'shape';
}

/** Whether a node inside a section's body would be on screen with the section open (nothing between is hidden). */
function shownIn(node, body) {
  for (let n = node; n && n !== body; n = n.parentElement) if (n.hidden) return false;
  return true;
}

/**
 * What a section is set to, read from its own controls in the order they appear: the size ("100 × 100 mm", or the
 * drawing's name and size while an SVG sets it), the chosen option of each group, each slider's read-out, and a switch
 * that is on. The line a closed section shows beside its title.
 */
export function summariseSection(body) {
  const parts = [];
  let switches = 0;
  for (const node of body.querySelectorAll('.size-inputs, button[aria-pressed="true"], .ctl-readout, input[role="switch"]')) {
    if (node.classList.contains('size-inputs')) {
      if (!node.hidden) {
        const [w, h] = [...node.querySelectorAll('input')].map((i) => i.value.trim());
        if (w && h) parts.push(`${w} × ${h} mm`);
      } else {
        const info = body.querySelector('#svg-lines-info');
        if (info && !info.hidden && info.textContent) parts.push(info.textContent);
      }
      continue;
    }
    if (!shownIn(node, body) || node.closest('.svg-layer-control')) continue;
    if (node.matches('input[role="switch"]')) {
      switches++;
      if (node.checked) parts.push(node.closest('label')?.querySelector('strong')?.textContent ?? 'On');
    } else if (node.matches('button[aria-pressed="true"]')) {
      const label = node.querySelector('.seg-main') ?? [...node.querySelectorAll(':scope > span')].filter((s) => !s.classList.contains('pattern-thumb')).at(-1);
      parts.push((label ?? node).textContent.trim());
    } else if (!node.closest('.ctl')?.querySelector('[aria-pressed="true"]')) {
      // a read-out that only repeats the option chosen beside it is left out
      parts.push(node.textContent.trim());
    }
  }
  const unique = [...new Set(parts.filter(Boolean))];
  if (!unique.length && switches) return 'Off';
  return unique.join(' · ');
}

/**
 * Collapse a whole section under a header that names it, shows a picture for it and, while it is closed, says what it is
 * set to. Every section starts closed, so a panel opens as a short list of what can be changed and what each is now.
 */
export class SectionFold extends Control {
  constructor(host, section, { id = 'section', open = false, icon = null } = {}) {
    super(host);
    this.node = section;
    const heading = section.querySelector('h2');
    const title = heading.textContent;
    this.body = el('div', { class: 'section-fold-body', id: `${id}-body`, hidden: !open });
    for (const child of [...section.childNodes]) if (child !== heading) this.body.append(child);
    this.button = el('button', { type: 'button', class: 'section-fold-toggle', 'aria-expanded': String(open), 'aria-controls': this.body.id });
    this.button.innerHTML = `<svg class="section-icon" width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${SECTION_ICONS[icon ?? sectionIcon(title)]}</svg>`;
    this.summary = el('span', { class: 'section-fold-summary' });
    this.button.append(el('span', { class: 'section-fold-title', text: title }), this.summary);
    this.button.insertAdjacentHTML('beforeend', CHEVRON);
    heading.replaceChildren(this.button);
    section.classList.add('section-fold');
    section.append(this.body);
    this.button.addEventListener('click', () => {
      this.body.hidden = !this.body.hidden;
      this.button.setAttribute('aria-expanded', String(!this.body.hidden));
    });
    // the summary follows the controls however they change: a click, a typed size, or a redraw from elsewhere
    this.queued = false;
    if (typeof MutationObserver !== 'undefined') {
      new MutationObserver(() => this.update()).observe(this.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['aria-pressed', 'hidden'] });
    }
    this.body.addEventListener('input', () => this.update());
    this.body.addEventListener('change', () => this.update());
    this.update();
  }

  /** Refresh the summary once the current round of changes is over, however many controls changed in it. */
  update() {
    if (this.queued) return;
    this.queued = true;
    queueMicrotask(() => {
      this.queued = false;
      const text = summariseSection(this.body);
      if (this.summary.textContent !== text) this.summary.textContent = text;
    });
  }
}

/**
 * Folds a grid of option buttons (the chosen one has aria-pressed) behind a single line showing the chosen option's
 * picture and name. Choosing an option closes it again, so a long list never takes the panel's room.
 * The grid is moved into the fold, wherever it was.
 */
export class OptionFold extends Control {
  constructor(host, grid, { id = 'options', none = 'Custom' } = {}) {
    super(host);
    this.grid = grid;
    this.none = none;
    if (!grid.id) grid.id = `${id}-options`;
    this.picture = el('span', { class: 'fold-picture', 'aria-hidden': 'true' });
    this.name = el('span', { class: 'disc-title' });
    this.sub = el('span', { class: 'disc-sub' });
    this.button = el('button', { type: 'button', class: 'option-fold-button', 'aria-expanded': 'false', 'aria-controls': grid.id },
      this.picture, el('span', { class: 'disc-text' }, this.name, this.sub));
    this.button.insertAdjacentHTML('beforeend', CHEVRON);
    this.node = el('div', { class: 'option-fold' }, this.button);
    if (grid.parentNode) grid.parentNode.insertBefore(this.node, grid);
    this.node.append(grid);
    this.setOpen(false);
    this.button.addEventListener('click', () => this.setOpen(this.grid.hidden));
    grid.addEventListener('click', (e) => { if (e.target.closest('button')) this.setOpen(false); });
    this.update();
  }

  setOpen(open) {
    this.grid.hidden = !open;
    this.button.setAttribute('aria-expanded', String(open));
  }

  update() {
    const buttons = [...this.grid.querySelectorAll('button')];
    const chosen = buttons.find((b) => b.getAttribute('aria-pressed') === 'true');
    const labels = chosen ? [...chosen.children].filter((c) => c.tagName === 'SPAN' && !c.classList.contains('pattern-thumb')) : [];
    this.name.textContent = chosen ? (labels.at(-1)?.textContent ?? chosen.textContent).trim() : this.none;
    this.sub.textContent = `${buttons.length} options`;
    this.button.title = chosen?.title ?? '';
    this.picture.replaceChildren();
    const pic = chosen?.querySelector('svg, canvas, .pattern-thumb');
    if (pic) {
      let copy;
      if (pic.tagName === 'CANVAS') {
        copy = el('canvas', { class: 'pattern-thumb', width: pic.width, height: pic.height });
        copy.getContext('2d').drawImage(pic, 0, 0);
      } else copy = pic.cloneNode(true);
      this.picture.append(copy);
    }
  }

  redraw() {
    this.update();
  }
}

/** The grid of pattern fields, and beside it the pattern-size slider (shown only while a pattern is chosen). */
export class PatternPicker extends Control {
  /**
   * @param scale        the slider description of the pattern size, or null
   * @param pictureHint  how this design reads the uploaded picture, shown with it, when `patterns` offers it
   */
  constructor(host, designId, key, patterns, titleId, { scale = null, pictureHint = '' } = {}) {
    super(host);
    this.designId = designId;
    this.key = key;
    this.grid = el('div', { class: 'patterns', role: 'group', 'aria-labelledby': titleId });
    const offersPicture = patterns.includes(PICTURE);
    // the picture is chosen from a file the first time: a hidden chooser, opened by the "Your picture" button
    this.fileInput = offersPicture ? el('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', class: 'visually-hidden', tabindex: '-1', 'aria-hidden': 'true', id: `${designId}-picture-file` }) : null;
    this.fileInput?.addEventListener('change', () => {
      const file = this.fileInput.files?.[0];
      if (file) host.loadPicture(file, designId);
      this.fileInput.value = '';
    });
    this.buttons = patterns.map((field) => {
      const canvas = el('canvas', { class: 'pattern-thumb', 'data-field': field, 'aria-hidden': 'true' });
      const picture = field === PICTURE;
      const special = { uniform: ['Even', 'Every strand has the same shape.'], gradientX: ['Across', 'The pattern changes from left to right.'], gradientY: ['Down', 'The pattern changes from bottom to top.'], centerSpot: ['Centre spot', 'The pattern is strongest at the centre.'], waves: ['Waves', 'A repeating wave field across the fabric.'] }[field];
      const label = picture ? 'Your picture' : field === 'none' ? 'Plain' : FIELDS[field]?.label ?? special?.[0] ?? field;
      const title = picture ? (pictureHint || 'Use a picture of your own as the pattern') : field === 'none' ? 'Every loop the same' : FIELDS[field]?.hint ?? special?.[1] ?? '';
      const btn = el('button', { type: 'button', class: 'pattern', 'data-choice': `${designId}:${key}:${field}`, 'aria-pressed': 'false', title }, canvas, el('span', { text: label }));
      btn.addEventListener('click', () => {
        if (picture && !host.picture?.()) { this.fileInput.click(); return; }
        host.settings(designId)[key] = field;
        host.change();
      });
      this.grid.append(btn);
      this.drawThumb(canvas, field);
      return { btn, field };
    });
    this.scaleBox = el('div', { id: `${designId}-pattern-scale`, class: 'pattern-scale' });
    this.scale = scale ? new SliderControl(host, designId, scale) : null;
    if (this.scale) this.scaleBox.append(this.scale.node);
    this.pictureBox = offersPicture ? this.buildPictureBox(pictureHint) : null;
    this.node = el('div', { class: 'pattern-picker' }, this.grid, this.scaleBox, this.pictureBox, this.fileInput);
  }

  /** The picture in use: how this design reads it, its name and size, and what can be done with it. */
  buildPictureBox(pictureHint) {
    const { host, designId } = this;
    this.pictureInfo = el('p', { class: 'small muted picture-info' });
    const choose = el('button', { type: 'button', class: 'link small', text: 'Choose another picture' });
    choose.addEventListener('click', () => this.fileInput.click());
    this.shapeButton = el('button', { type: 'button', class: 'link small', text: 'Give the piece the picture\'s shape' });
    this.shapeButton.addEventListener('click', () => host.pictureShape(designId));
    const remove = el('button', { type: 'button', class: 'link small', text: 'Remove picture' });
    remove.addEventListener('click', () => host.clearPicture());
    const box = el('div', { class: 'picture-box', id: `${designId}-picture-box` },
      pictureHint ? el('p', { class: 'small', text: pictureHint }) : null,
      this.pictureInfo,
      el('div', { class: 'picture-actions' }, choose, this.shapeButton, remove));
    // a picture dropped on the box (or on the whole picker) replaces the one in use
    for (const target of [box, this.grid]) {
      target.addEventListener('dragover', (e) => { if (e.dataTransfer?.types?.includes('Files')) { e.preventDefault(); target.classList.add('dragover'); } });
      target.addEventListener('dragleave', () => target.classList.remove('dragover'));
      target.addEventListener('drop', (e) => {
        const file = e.dataTransfer?.files?.[0];
        target.classList.remove('dragover');
        if (!file) return;
        e.preventDefault();
        host.loadPicture(file, designId);
      });
    }
    return box;
  }

  /** A pattern's button picture: the field itself, the uploaded picture, or an upload arrow before there is one. */
  drawThumb(canvas, field) {
    if (field !== PICTURE) { drawFieldThumb(canvas, field); return; }
    const ratio = Math.min(window.devicePixelRatio || 1, 2), size = 48;
    canvas.width = size * ratio;
    canvas.height = size * ratio;
    const ctx = canvas.getContext('2d');
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, size, size);
    const image = this.host.picture?.();
    if (image?.thumb) { ctx.drawImage(image.thumb, 0, 0, size, size); return; }
    const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#34469a';
    ctx.strokeStyle = accent;
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(24, 31); ctx.lineTo(24, 14); ctx.moveTo(17, 21); ctx.lineTo(24, 14); ctx.lineTo(31, 21); ctx.moveTo(13, 36); ctx.lineTo(35, 36);
    ctx.stroke();
  }

  redraw() {
    for (const { btn, field } of this.buttons) this.drawThumb(btn.querySelector('canvas'), field);
    this.fold?.update();
  }

  update() {
    const s = this.host.settings(this.designId);
    for (const { btn, field } of this.buttons) {
      btn.setAttribute('aria-pressed', String(String(s[this.key]) === field));
      if (field === PICTURE) this.drawThumb(btn.querySelector('canvas'), field); // the picture may have changed
    }
    this.fold?.update();
    const picture = s[this.key] === PICTURE;
    this.scaleBox.hidden = !s.pattern || s.pattern === 'none' || picture; // a picture is laid over the whole piece
    this.scale?.update();
    if (this.pictureBox) {
      const image = this.host.picture?.();
      this.pictureBox.hidden = !picture || !image;
      if (image) {
        const [w, h] = this.host.binding(this.designId)?.size?.get?.() ?? [0, 0];
        const shaped = w && h && Math.abs(w / h - image.px[0] / image.px[1]) < 0.02;
        this.pictureInfo.textContent = `${image.name} · ${image.px[0]} × ${image.px[1]} px · ${shaped ? 'the piece has its shape' : 'stretched to fill the piece'}`;
        this.shapeButton.hidden = !!shaped;
      }
    }
  }
}

/* ---------- sections of a design's panel ---------- */

/** A titled group that shows only while its `when(settings)` is true (always, when it has none). */
export class Section extends Control {
  /** @param spec one entry of the design's `controls`; @param position { index, sliderGroup } */
  constructor(host, mod, spec, position) {
    super(host);
    this.mod = mod;
    this.spec = spec;
    this.position = position;
    this.titleId = `${mod.id}-group-${position.index}-title`;
    // a section without a title (a lone switch) is a row of its own: there is nothing to fold it under
    const titled = !!spec.title;
    this.node = el('section', { class: titled ? 'group' : 'group untitled', 'aria-labelledby': titled ? this.titleId : false },
      titled ? el('h2', { class: 'eyebrow', id: this.titleId, text: spec.title }) : null);
    for (const part of [].concat(this.buildBody())) if (part) this.node.append(part);
    this.fold = titled ? new SectionFold(host, this.node, { id: this.titleId, icon: sectionIcon(spec.title, spec.kind) }) : null;
    this.fold?.button.addEventListener('click', () => { if (!this.fold.body.hidden) this.opened(); });
  }

  /** The section was opened. The default does nothing. */
  opened() {}

  get settings() {
    return this.host.settings(this.mod.id);
  }

  get visible() {
    return typeof this.spec.when === 'function' ? !!this.spec.when(this.settings) : true;
  }

  /** The nodes under the title. */
  buildBody() {
    return [];
  }

  /** Refresh what is inside the group. */
  refresh() {}

  update() {
    this.node.hidden = !this.visible;
    if (!this.node.hidden) this.refresh();
    this.fold?.update();
  }

  hint() {
    return this.spec.hint ? el('p', { class: 'group-hint', text: this.spec.hint }) : null;
  }
}

/** Loom draft editor: repeatable threading, tie-up and treadling with a live drawdown and row cross-section. */
export class DraftSection extends Section {
  buildBody() {
    this.body=el('div',{class:'draft-editor'});
    this.presetButtons=el('div',{class:'draft-presets','role':'group','aria-label':'Draft presets'});
    for(const [id,label] of [['point-twill','Point twill'],['block','Block weave'],['herringbone','Herringbone'],['custom','Custom']]){
      const button=el('button',{type:'button',class:'btn small',text:label,'data-draft-preset':id});
      button.addEventListener('click',()=>this.applyPreset(id));this.presetButtons.append(button);
    }
    this.validation=el('p',{class:'draft-validation small','aria-live':'polite',role:'status'});
    this.grids=el('div',{class:'draft-grids'});
    this.threading=el('div',{class:'draft-grid-wrap'});this.tieup=el('div',{class:'draft-grid-wrap'});this.treadling=el('div',{class:'draft-grid-wrap'});
    this.drawdown=el('div',{class:'draft-drawdown-wrap'});this.crossSection=el('div',{class:'draft-cross-section'});
    this.grids.append(this.threading,this.tieup,this.treadling);
    this.body.append(this.presetButtons,this.validation,this.grids,this.drawdown,this.crossSection);
    return this.body;
  }

  applyPreset(id){
    const draft=WEAVE_DRAFT_PRESETS[id];if(draft)this.settings.draft={preset:id,...structuredClone(draft)};else this.settings.draft={...this.settings.draft,preset:'custom'};
    this.host.change();
  }

  refresh(){
    const draft=this.settings.draft;
    for(const button of this.presetButtons.querySelectorAll('[data-draft-preset]'))button.setAttribute('aria-pressed',String(button.dataset.draftPreset===draft.preset));
    const shafts=Math.max(1,draft.tieup.length),treadles=Math.max(1,...draft.tieup.map(row=>row.length));
    this.threading.replaceChildren(el('h3',{text:'Threading · shaft for each warp'}),...draft.threading.map((shaft,index)=>{
      const button=el('button',{type:'button',class:'draft-cell',text:String(shaft+1),title:`Warp ${index+1}: shaft ${shaft+1}`,'aria-label':`Warp ${index+1}, shaft ${shaft+1}`});
      button.addEventListener('click',()=>{draft.threading[index]=(shaft+1)%shafts;draft.preset='custom';this.host.change();});return button;
    }));
    this.tieup.replaceChildren(el('h3',{text:'Tie-up · shafts × treadles'}));
    const table=el('table',{class:'draft-matrix','aria-label':'Tie-up matrix'}),head=el('tr',{},el('th',{text:'Shaft'}),...Array.from({length:treadles},(_,j)=>el('th',{text:`T${j+1}`})));table.append(el('thead',{},head));
    const tbody=el('tbody');draft.tieup.forEach((row,i)=>{const tr=el('tr',{},el('th',{scope:'row',text:`S${i+1}`}));for(let j=0;j<treadles;j++){const active=!!row[j],button=el('button',{type:'button',class:'draft-cell tieup-cell',text:active?'●':'—','aria-pressed':String(active),'aria-label':`Shaft ${i+1}, treadle ${j+1}, ${active?'tied':'not tied'}`});button.addEventListener('click',()=>{row[j]=!row[j];draft.preset='custom';this.host.change();});tr.append(el('td',{},button));}tbody.append(tr);});table.append(tbody);this.tieup.append(table);
    this.treadling.replaceChildren(el('h3',{text:'Treadling · treadle for each pick'}),...draft.treadling.map((treadle,index)=>{const button=el('button',{type:'button',class:'draft-cell',text:String(treadle+1),title:`Pick ${index+1}: treadle ${treadle+1}`,'aria-label':`Pick ${index+1}, treadle ${treadle+1}`});button.addEventListener('click',()=>{draft.treadling[index]=(treadle+1)%treadles;draft.preset='custom';this.host.change();});return button;}));
    let binding,error='';try{binding=draftBinding(draft);}catch(exception){error=exception.message;}
    if(error){this.validation.textContent=error;this.validation.classList.add('is-error');this.drawdown.replaceChildren();this.crossSection.replaceChildren();return;}
    this.validation.classList.remove('is-error');
    const columns=Math.min(24,Math.max(1,draft.threading.length)),rows=Math.min(24,Math.max(1,draft.treadling.length));
    let longest=0;for(let i=0;i<draft.threading.length;i++)for(const over of [true,false]){let run=0;for(let j=0;j<draft.treadling.length*2;j++){if(binding.over(i,j)===over){run++;longest=Math.max(longest,run);}else run=0;}}
    this.validation.textContent=longest>4?`Long floats (${longest} crossings) sag and snag.`:'Draft is bound in both directions; no float exceeds four crossings.';
    const svg=svgEl('svg',{viewBox:`0 0 ${columns*18} ${rows*18}`,role:'img','aria-label':'Live weave drawdown; raised cells mean warp is over weft'});
    const cross=this.crossSection;
    const paintCross=(pick)=>{
      const strip=svgEl('svg',{viewBox:`0 0 ${columns*18} 54`,role:'img','aria-label':`Cross-section at pick ${pick+1}`});
      for(let i=0;i<columns;i++){
        const over=binding.over(i,pick),x=i*18;
        strip.append(svgEl('rect',{x,y:over?30:8,width:17,height:9,rx:1,fill:'var(--ink, #333)',opacity:'.55'}));
        strip.append(svgEl('rect',{x,y:over?8:30,width:17,height:9,rx:1,fill:'var(--accent, #8d5137)'}));
      }
      cross.replaceChildren(el('span',{class:'small muted',text:`Cross-section · pick ${pick+1} · dark weft, accent warp`}),strip);
    };
    for(let j=0;j<rows;j++)for(let i=0;i<columns;i++){const over=binding.over(i,j),rect=svgEl('rect',{x:i*18,y:j*18,width:17,height:17,rx:1,fill:over?'var(--accent, #8d5137)':'var(--ink, #333)',opacity:over?'.9':'.48',tabindex:0,role:'button','aria-label':`Warp ${i+1}, pick ${j+1}: ${over?'warp over':'weft over'}`});rect.addEventListener('pointerenter',()=>paintCross(j));rect.addEventListener('focus',()=>paintCross(j));svg.append(rect);}
    this.drawdown.replaceChildren(el('h3',{text:'Drawdown · select or hover a pick for its cross-section'}),svg);paintCross(0);
  }
}

/** A grid of option buttons, one of which is pressed. Subclasses say what the options are. */
class OptionSection extends Section {
  /** @returns [{ attrs, html?, text?, hint, pressed(), apply() }] */
  options() {
    return [];
  }

  gridAttrs() {
    return {};
  }

  buildBody() {
    this.grid = el('div', { class: 'patterns', role: 'group', 'aria-labelledby': this.titleId, ...this.gridAttrs() });
    this.pictures = [];
    this.buttons = this.options().map((opt) => {
      const btn = el('button', { type: 'button', class: 'pattern', 'aria-pressed': 'false', title: opt.hint, ...opt.attrs });
      if (opt.html !== undefined) btn.innerHTML = opt.html;
      else btn.append(el('span', { text: opt.text }));
      // a picture drawn from the design itself waits until the section is first opened
      if (opt.picture) {
        const slot = el('span', { class: 'option-picture', 'aria-hidden': 'true' });
        btn.prepend(slot);
        this.pictures.push({ slot, draw: opt.picture });
      }
      // an option that cannot be chosen here stays visible, with its reason as the hint
      if (opt.disabled) btn.disabled = true;
      btn.addEventListener('click', () => { opt.apply(); this.host.change(); });
      this.grid.append(btn);
      return { btn, opt };
    });
    return [this.hint(), this.grid];
  }

  refresh() {
    for (const { btn, opt } of this.buttons) btn.setAttribute('aria-pressed', String(opt.pressed()));
  }

  /** Draws the waiting pictures one at a time, so the section opens at once and fills in. */
  opened() {
    const queue = this.pictures.splice(0);
    const step = () => {
      const job = queue.shift();
      if (!job) return;
      job.slot.innerHTML = job.draw();
      if (!job.slot.innerHTML) job.slot.hidden = true;
      setTimeout(step, 0);
    };
    if (queue.length) setTimeout(step, 0);
  }
}

/** "Start from": recipes that change several settings at once. */
export class PresetsSection extends OptionSection {
  gridAttrs() {
    return { id: `${this.mod.id}-presets` };
  }

  options() {
    const safe = (text) => String(text).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
    return this.mod.presets.map((p) => ({
      attrs: { 'data-preset': p.id },
      // what the preset prints as at 100 x 100 mm sits under its name, so the choices can be compared without opening each
      ...((line) => (line ? { html: `<span>${safe(p.name)}</span><span class="preset-estimate">${line}</span>` } : { text: p.name }))(estimateLine(CARD_ESTIMATES[`${this.mod.id}:${p.id}`])),
      hint: p.blurb,
      picture: this.mod.presetPicture ? () => this.mod.presetPicture(p) : this.host.presetPicture ? () => this.host.presetPicture(this.mod, p) : null,
      pressed: () => (this.mod.presetMatch ? this.mod.presetMatch(this.settings) : null) === p.id,
      apply: () => Object.assign(this.settings, p.patch),
    }));
  }
}

/** One of the strand shapes of the shape library. */
export class ShapeSection extends OptionSection {
  options() {
    const { key } = this.spec;
    return this.mod.shapes.map((shape) => ({
      attrs: { 'data-choice': `${this.mod.id}:${key}:${shape}` },
      html: `${shapeThumb(shape)}<span>${SHAPES[shape].label}</span>`,
      hint: SHAPES[shape].hint,
      pressed: () => String(this.settings[key]) === shape,
      apply: () => { this.settings[key] = shape; },
    }));
  }
}

/** One value out of a short list. An option may carry a `patch`: the sizes and angles that suit it. */
export class ChoiceSection extends OptionSection {
  options() {
    const { key } = this.spec;
    return this.spec.options.map((opt) => ({
      attrs: { 'data-choice': `${this.mod.id}:${key}:${opt.id}` },
      html: `${opt.thumb ?? ''}<span>${opt.label}</span>`,
      hint: opt.hint,
      picture: opt.thumb ? null : opt.picture ?? null,
      disabled: !!opt.disabled,
      pressed: () => String(this.settings[key]) === String(opt.value ?? opt.id),
      apply: () => { Object.assign(this.settings, opt.patch ?? {}); this.settings[key] = opt.value ?? opt.id; },
    }));
  }
}

/** A small editable polar petal; pointer and keyboard edits update one metric span at a time. */
export class PetalSection extends Section {
  buildBody(){
    this.svg=svgEl('svg',{viewBox:'0 0 240 180',class:'petal-editor',role:'group','aria-label':this.spec.hint??'Edit petal metric'});
    this.rays=[];this.handles=[];
    this.svg.addEventListener('pointerdown',event=>{const target=event.target.closest('[data-handle]');if(target){target.setPointerCapture(event.pointerId);this.dragIndex=Number(target.dataset.handle);this.drag(event);}});
    this.svg.addEventListener('pointermove',event=>{if(this.dragIndex!==undefined)this.drag(event);});
    this.svg.addEventListener('pointerup',()=>{this.dragIndex=undefined;this.host.commit?.();});
    // returned for the section to hold: `this.node` is the section itself, and appending it to itself throws
    return el('div',{class:'petal-control'},this.hint(),this.svg);
  }
  get values(){const value=this.settings[this.spec.key];return Array.isArray(value)?value.slice(0,7):[1,.6,1];}
  update(){
    const values=this.values,n=values.length,cx=120,cy=90,maximum=1.5,points=[];
    for(let i=0;i<n*2;i++){
      const angle=Math.PI*2*i/(n*2),sector=i%(n*2),idx=Math.floor(sector/2),t=(sector%2)*.5;
      const radius=values[idx]*(1-t)+(values[(idx+1)%n]??values[idx])*t;
      points.push(`${cx+radius/maximum*68*Math.cos(angle)},${cy+radius/maximum*68*Math.sin(angle)}`);
    }
    this.svg.replaceChildren(svgEl('polygon',{points:points.join(' '),class:'petal-shape'}));
    this.handles=values.map((value,index)=>{
      const angle=2*Math.PI*index/n,x=cx+value/maximum*68*Math.cos(angle),y=cy+value/maximum*68*Math.sin(angle);
      const circle=svgEl('circle',{cx:x,cy:y,r:9,class:'petal-handle',tabindex:'0',role:'slider','aria-label':`Petal span ${index+1}`,'aria-valuemin':'.3','aria-valuemax':'1.5','aria-valuenow':value,'data-handle':index});
      circle.addEventListener('keydown',event=>{if(!['ArrowUp','ArrowRight','ArrowDown','ArrowLeft'].includes(event.key))return;event.preventDefault();const next=this.values;next[index]=Math.max(.3,Math.min(1.5,Math.round((next[index]+(['ArrowUp','ArrowRight'].includes(event.key)?0.05:-0.05))*20)/20));this.settings[this.spec.key]=next;this.host.change();});
      this.svg.append(circle);return circle;
    });
  }
  drag(event){
    const rect=this.svg.getBoundingClientRect(),x=(event.clientX-rect.left)/rect.width*240-120,y=(event.clientY-rect.top)/rect.height*180-90;
    const index=this.dragIndex,angle=2*Math.PI*index/this.values.length,radial=(x*Math.cos(angle)+y*Math.sin(angle))/68*1.5;
    const next=this.values;next[index]=Math.max(.3,Math.min(1.5,Math.round(radial*20)/20));this.settings[this.spec.key]=next;this.host.nudge();this.update();
  }
}

/** An on/off switch with its explanation beside it. */
export class SwitchSection extends Section {
  buildBody() {
    const { key, label, help } = this.spec;
    this.input = el('input', { type: 'checkbox', role: 'switch', 'data-switch': `${this.mod.id}:${key}` });
    this.input.addEventListener('change', () => { this.settings[key] = this.input.checked; this.host.change(); });
    return el('label', { class: 'switch-row' }, this.input, el('span', {}, el('strong', { text: label }), el('small', { text: help })));
  }

  refresh() {
    this.input.checked = !!this.settings[this.spec.key];
  }
}

/** The size of the swatch, with its error line. */
export class SizeSection extends Section {
  buildBody() {
    this.size = new SizeControl(this.host, this.mod.id);
    return el('div', { id: `${this.mod.id}-size` }, this.size.node);
  }

  refresh() {
    this.size.update();
  }
}

/** A group of sliders. */
export class SlidersSection extends Section {
  buildBody() {
    const suffix = this.position.sliderGroup ? `-${this.position.sliderGroup}` : '';
    const main = this.spec.items.filter((def) => !def.advanced).map((def) => new SliderControl(this.host, this.mod.id, def));
    const extra = this.spec.items.filter((def) => def.advanced).map((def) => new SliderControl(this.host, this.mod.id, def));
    this.sliders = [...main, ...extra];
    const body = el('div', { id: `${this.mod.id}-sliders${suffix}`, class: 'controls' }, ...main.map((s) => s.node));
    // settings most people leave alone sit in a closed drawer under the others
    if (!extra.length) return body;
    return [body, el('details', { class: 'advanced-sliders' }, el('summary', { text: 'Advanced' }), el('div', { class: 'controls' }, ...extra.map((s) => s.node)))];
  }

  refresh() {
    for (const s of this.sliders) s.update();
  }
}

/** A grid of pattern fields (the brightness map a design reads) and its size slider. */
export class PatternSection extends Section {
  buildBody() {
    this.picker = new PatternPicker(this.host, this.mod.id, this.spec.key, this.mod.patterns, this.titleId, { scale: this.spec.scale ?? null, pictureHint: this.spec.pictureHint ?? '' });
    this.effects = this.mod.patternEffects ?? [];
    this.effectPicker = this.effects.length > 1 ? el('div', { class: 'patterns pattern-effects', role: 'group', 'aria-label': 'Pattern effect' },
      ...this.effects.map((effect) => {
        const def = PATTERN_EFFECTS[effect];
        const button = el('button', { type: 'button', class: 'pattern', 'data-pattern-effect': effect, title: def?.hint ?? '' }, el('span', { text: def?.label ?? effect }));
        button.addEventListener('click', () => { this.settings.patternEffect = effect; this.host.change(); });
        return button;
      })) : null;
    this.effectButtons = [...(this.effectPicker?.querySelectorAll('[data-pattern-effect]') ?? [])];
    this.thickness = this.effects.includes('thickness') ? ['thin', 'thick'].map((key) => new SliderControl(this.host, this.mod.id, {
      key, label: key === 'thin' ? 'Thinnest' : 'Thickest', help: 'Extrusion flow multiplier at the light and dark ends of the pattern.',
      lo: key === 'thin' ? 'Lighter' : 'Thinner', hi: key === 'thin' ? 'Heavier' : 'Thicker', unit: '×', edit: true,
    })) : [];
    this.thicknessNode = el('div', { class: 'controls pattern-thickness' }, ...this.thickness.map((control) => control.node));
    return [this.hint(), this.picker.node, this.effectPicker, this.thicknessNode];
  }

  refresh() {
    this.picker.update();
    const effect = this.settings.patternEffect ?? this.effects[0];
    for (const button of this.effectButtons) button.setAttribute('aria-pressed', String(button.dataset.patternEffect === effect));
    this.thicknessNode.hidden = effect !== 'thickness';
    if (!this.thicknessNode.hidden) for (const control of this.thickness) control.update();
  }

  redraw() {
    this.picker.redraw();
  }
}

const COLOUR_MODES = Object.freeze({
  one: { label: 'One colour', hint: 'The whole piece in one filament.' },
  face: { label: 'Face colour', hint: 'The first layer, the side on the bed, in its own colour. Pauses once to change filament.' },
  'per-layer': { label: 'Colour per layer', hint: 'Choose a colour for every layer. Pauses before each change.' },
  halftone2: { label: 'Two-colour halftone', hint: 'Each line family in its own colour, so the picture shows in two tones.' },
});

/** Colour mode and optional per-layer preview colours for a card. */
export class ColourSection extends Section {
  buildBody() {
    this.modes = this.mod.colourModes ?? Object.keys(COLOUR_MODES).filter((mode) => mode !== 'halftone2');
    this.buttons = this.modes.map((mode) => {
      const option = COLOUR_MODES[mode];
      const button = el('button', { type: 'button', class: 'pattern', 'aria-pressed': 'false', 'data-colour-mode': mode, title: option?.hint ?? '' }, el('span', { text: option?.label ?? mode }));
      button.addEventListener('click', () => {
        this.settings.colourMode = mode;
        this.settings.colorChange = mode === 'face' || mode === 'halftone2';
        if (mode === 'halftone2') this.settings.patternEffect = 'thickness';
        this.host.change();
      });
      return { mode, button };
    });
    this.grid = el('div', { class: 'patterns colour-modes', role: 'group', 'aria-label': 'Colour mode' }, ...this.buttons.map((entry) => entry.button));
    this.colours = el('div', { class: 'layer-colours' });
    return [this.hint(), this.grid, this.colours];
  }

  refresh() {
    const mode = this.settings.colourMode ?? 'one';
    for (const { mode: option, button } of this.buttons) button.setAttribute('aria-pressed', String(mode === option));
    this.colours.replaceChildren();
    if (mode === 'one') return;
    const count = mode === 'per-layer' ? Math.min(256, Math.max(1, Number(this.spec.layerCount?.(this.settings) ?? this.host.layerCount?.(this.mod.id) ?? this.settings.layerColours?.length ?? 2))) : 2;
    const colours = Array.isArray(this.settings.layerColours) ? [...this.settings.layerColours] : [];
    while (colours.length < count) colours.push(colours.length % 2 ? '#222222' : '#f2e6d8');
    this.settings.layerColours = colours;
    for (let i = 0; i < count; i++) {
      const input = el('input', { type: 'color', value: colours[i], 'aria-label': `Layer ${i + 1} colour` });
      input.value = /^#[\da-f]{6}$/i.test(colours[i]) ? colours[i] : '#8ea5ff';
      input.addEventListener('input', () => { this.settings.layerColours[i] = input.value; });
      input.addEventListener('change', () => { this.settings.layerColours[i] = input.value; this.host.change(); });
      this.colours.append(el('label', { class: 'layer-colour' }, el('span', { text: `Layer ${i + 1}` }), input));
    }
  }
}

/** A card's carrier settings; built-in carriers are explanatory and read-only. */
export class SupportSection extends Section {
  buildBody() {
    if (this.mod.support === 'built-in' || this.spec.readonly) return el('p', { class: 'group-hint', text: 'This design prints its own carrier.' });
    const changed = () => { delete this.support.passes; this.host.change(); };
    this.enabled = this.spec.optional ? el('input', { type: 'checkbox', 'aria-label': 'Use a carrier' }) : null;
    this.enabled?.addEventListener('change', () => { this.support.enabled = this.enabled.checked; this.host.change(); });
    this.area = this.spec.area ? el('select', { 'aria-label': 'Carrier covers' }, ...[['swatch', 'The whole swatch'], ['shape', 'The shapes only'], ['box', "The drawing’s box"]].map(([value, text]) => el('option', { value, text }))) : null;
    this.area?.addEventListener('change', () => { this.support.area = this.area.value; this.host.change(); });
    const options = (this.spec.styles ?? BACKING_STYLES).concat((this.spec.styles ?? BACKING_STYLES).includes('zigzag') ? [] : ['zigzag']);
    this.styleButtons = options.map((style) => {
      const button = el('button', { type: 'button', class: 'pattern', 'aria-pressed': 'false', 'data-support-style': style, text: style[0].toUpperCase() + style.slice(1) });
      button.addEventListener('click', () => { this.support.style = style; changed(); });
      return button;
    });
    this.styleGrid = el('div', { class: 'patterns support-styles', role: 'group', 'aria-label': 'Carrier style' }, ...this.styleButtons);
    this.fields = {};
    const ranges = this.spec.ranges ?? {};
    const defaults = { openness: 5, depth: 2, wavelength: 10, layers: 1, angle: 45 };
    const controls = Object.entries(defaults).map(([key, fallback]) => {
      const range = ranges[key] ?? (key === 'layers' ? { min: 1, max: 2, step: 1 } : key === 'angle' ? { min: -180, max: 180, step: 1 } : { min: key === 'depth' ? 0 : .5, max: key === 'depth' ? 20 : key === 'wavelength' ? 100 : 50, step: .1 });
      const input = el('input', { type: 'number', min: range.min, max: range.max, step: range.step, 'data-support-key': key, 'aria-label': ({ openness: 'Openness', depth: 'Depth', wavelength: 'Wavelength', layers: 'Carrier layers', angle: 'Angle' })[key] });
      input.addEventListener('change', () => {
        const value = Number(input.value);
        if (input.value === '' || !Number.isFinite(value) || value < range.min || value > range.max || key === 'layers' && !Number.isInteger(value)) { input.value = String(this.support[key] ?? fallback); this.host.toast?.(`Enter ${range.min} to ${range.max} for ${key}.`); return; }
        this.support[key] = value; changed();
      });
      this.fields[key] = { input, fallback };
      return el('label', { class: 'support-field' }, el('span', { text: ({ openness: 'Openness (mm)', depth: 'Depth (mm)', wavelength: 'Wavelength (mm)', layers: 'Layers', angle: 'Angle (°)' })[key] }), input);
    });
    this.controls = el('div', { class: 'support-controls' }, ...controls);
    this.savedNote = el('p', { class: 'group-hint small', text: 'Saved custom carrier patterns are preserved until you change the style or dimensions.' });
    return [this.hint(), this.enabled ? el('label', { class: 'support-enabled' }, this.enabled, el('span', { text: 'Use a carrier' })) : null, this.area ? el('label', { class: 'support-field' }, el('span', { text: 'Carrier covers' }), this.area) : null, this.styleGrid, this.controls, this.savedNote];
  }

  get support() {
    if (!this.settings.support || typeof this.settings.support !== 'object') this.settings.support = {};
    return this.settings.support;
  }

  refresh() {
    if (!this.styleButtons) return;
    const value = this.support;
    if (this.enabled) this.enabled.checked = value.enabled !== false;
    if (this.area) this.area.value = value.area ?? 'swatch';
    this.styleGrid.hidden = this.controls.hidden = value.enabled === false;
    this.savedNote.hidden = !value.passes?.length || value.enabled === false;
    for (const button of this.styleButtons) button.setAttribute('aria-pressed', String(button.dataset.supportStyle === (value.style ?? 'straight')));
    for (const [key, { input, fallback }] of Object.entries(this.fields)) input.value = String(value[key] ?? fallback);
  }
}

/** Returns panel-template contract violations for one card's controls list. */
export function panelOrderErrors(controls = []) {
  const errors = [];
  const groups = { presets: 0, size: 1, choice: 2, petal: 2, draft: 2, sliders: 3, switch: 3, pattern: 4, colour: 5, support: 6 };
  let last = -1;
  const seen = new Set();
  let slidersSeen = false;
  for (const [index, spec] of controls.entries()) {
    if (!spec || typeof spec !== 'object') { errors.push(`Control ${index + 1} is not a section.`); continue; }
    if (spec.kind === 'shape') { errors.push('The shape section is not allowed on library cards.'); continue; }
    if (spec.kind === 'switch' && spec.key === 'colorChange') { errors.push('Use the colour section instead of the colorChange switch.'); continue; }
    const group = groups[spec.kind];
    if (group === undefined) { errors.push(`Unknown section kind: ${spec.kind}.`); continue; }
    if (group < last) errors.push(`${spec.kind} is out of panel order.`);
    if (spec.kind !== 'choice' && seen.has(spec.kind)) errors.push(`${spec.kind} appears more than once.`);
    if (spec.kind === 'switch' && !slidersSeen) errors.push('A switch must immediately follow the sliders section.');
    if (spec.kind === 'sliders') slidersSeen = true;
    else if (spec.kind !== 'switch' && group > 3) slidersSeen = false;
    seen.add(spec.kind);
    last = Math.max(last, group);
  }
  return errors;
}

/** What a section is called in a design's `controls` list, and the class that draws it. */
export const SECTION_TYPES = {
  presets: PresetsSection,
  size: SizeSection,
  shape: ShapeSection,
  choice: ChoiceSection,
  petal: PetalSection,
  switch: SwitchSection,
  sliders: SlidersSection,
  pattern: PatternSection,
  colour: ColourSection,
  support: SupportSection,
  draft: DraftSection,
};

/** One design's whole panel: its name, then its sections in the order its registry entry lists them. */
export class DesignPanel extends Control {
  constructor(host, mod) {
    super(host);
    this.mod = mod;
    this.joins = mod.joins ? el('p', { class: 'panel-joins', text: mod.joins }) : null;
    this.badges = el('div', { class: 'panel-badges', 'aria-label': 'Card status' },
      el('span', { class: 'design-badge', text: ({ self: 'Holds itself', auto: 'Uses a carrier', 'built-in': 'Built-in carrier' })[mod.support] ?? 'Support not set' }),
      el('span', { class: `design-badge state-${mod.state ?? 'untested'}`, text: ({ tested: 'Tested', untested: 'Untested', 'needs-repair': 'Needs repair' })[mod.state] ?? 'Untested' }));
    const variants = variantsOf(mod.id).filter((card) => card.id !== mod.id);
    this.printVariants = variants.length ? el('button', { type: 'button', class: 'btn small', text: 'Print all variants', title: 'Place each variant on one bed for a side-by-side comparison' }) : null;
    this.printVariants?.addEventListener('click', () => this.host.printVariants?.(mod.id));
    this.alsoOn = variants.length ? el('nav', { class: 'variant-links', 'aria-label': 'Also on' },
      el('span', { class: 'small muted', text: 'Also on:' }), ...variants.map((card) => {
        const button = el('button', { type: 'button', class: 'link small', text: SHELVES[card.shelf].label });
        button.addEventListener('click', () => this.host.switchDesign?.(card.id));
        return button;
      })) : null;
    this.node = el('div', { id: `panel-${mod.id}`, class: 'panel', hidden: true },
      el('header', { class: 'panel-head' }, el('h1', { class: 'title', text: mod.name }), this.badges, ...(this.joins ? [this.joins] : []), ...(this.alsoOn ? [this.alsoOn] : []), ...(this.printVariants ? [this.printVariants] : [])));
    this.sections = [];
    let sliderGroup = 0;
    mod.controls.forEach((spec, index) => {
      const Type = SECTION_TYPES[spec.kind];
      if (!Type) throw new Error(`${mod.id}: no section type for "${spec.kind}"`);
      const section = new Type(host, mod, spec, { index, sliderGroup: spec.kind === 'sliders' ? sliderGroup++ : 0 });
      this.sections.push(section);
      this.node.append(section.node);
    });
  }

  update() {
    for (const section of this.sections) section.update();
  }

  redraw() {
    for (const section of this.sections) section.redraw();
  }
}

/**
 * The layer setup every design shares, kept in the printer setup: how thick each layer is (only the thicknesses the
 * nozzle can lay down are offered) and how many individual passes to add to the original design. One card for the whole
 * studio, so a change is made once. The host's 'print' binding gives { get, set, range, readout, options(), note() }.
 * @param defs { thickness: { label, help }, layers: a slider description }
 */
export class PrintSetupCard extends Control {
  constructor(host, { thickness, layers, solids = null }) {
    super(host);
    this.layers = new SliderControl(host, 'print', layers);
    this.solids = solids ? new SliderControl(host, 'print', solids) : null;
    this.readout = el('span', { class: 'ctl-readout', id: 'layer-thickness-value' });
    this.thicknessHelp = helpBubble(thickness.label, thickness.help);
    this.grid = el('div', { class: 'patterns layer-choices', id: 'layer-thickness-choices', role: 'group', 'aria-labelledby': 'layer-thickness-label' });
    this.built = '';
    this.fold = null;
    this.node = el('section', { class: 'print-setup', 'aria-labelledby': 'print-setup-title' },
      el('h3', { id: 'print-setup-title', text: 'Layers' }),
      el('div', { class: 'ctl' },
        el('div', { class: 'ctl-top' }, el('span', { class: 'ctl-heading' },
          el('span', { class: 'ctl-label', id: 'layer-thickness-label', text: thickness.label }), this.thicknessHelp), this.readout),
        this.grid),
      this.layers.node, this.solids?.node);
  }

  get binding() {
    return this.host.binding('print');
  }

  build(options) {
    const { binding } = this;
    this.grid.replaceChildren(...options.map((v) => {
      const btn = el('button', { type: 'button', class: 'pattern', 'data-layer-height': String(v), 'aria-pressed': 'false', text: `${v} mm` });
      btn.addEventListener('click', () => { binding.set('layerHeight', v); this.host.nudge(); this.host.commit(); });
      return btn;
    }));
    this.built = options.join(',');
    if (!this.fold && options.length > FOLD_AFTER) this.fold = new OptionFold(this.host, this.grid, { id: 'layer-thickness' });
  }

  update() {
    const { binding } = this;
    const options = binding.options();
    if (options.join(',') !== this.built) this.build(options);
    for (const btn of this.grid.children) btn.setAttribute('aria-pressed', String(Number(btn.dataset.layerHeight) === binding.get('layerHeight')));
    this.readout.textContent = binding.readout('layerHeight');
    this.fold?.update();
    this.layers.update();
    this.solids?.update();
  }

  redraw() {
    this.fold?.update();
  }
}

/* ---------- the one place a drawing comes in ---------- */

/** The sample drawing on the site (samples/), to try or to open and copy: red fills, a blue hole, yellow and green solids, lines. */
export const SAMPLE_SVG = 'samples/filafabric-sample.svg';


/**
 * The SVG import. A drawing comes in once, here, and does three things everywhere in the studio: its lines print first,
 * the swatch takes its size, and (if you ask) the pattern is cut to its closed shapes. `host.svg()` describes the
 * situation: { vector, summary, usesVector, designNote, allowsOutline, hasShapes, outlineOn, window }, and the card calls
 * host.importSvg(file), host.removeSvg() and host.setShapeOutline(on).
 */
export class SvgImportCard extends Control {
  constructor(host) {
    super(host);
    this.input = el('input', { type: 'file', accept: '.svg,image/svg+xml', class: 'visually-hidden', id: 'svg-lines-input', tabindex: '-1' });
    this.pickText = el('span', { text: 'Import SVG' });
    this.pick = el('label', { class: 'btn svg-import', for: 'svg-lines-input', tabindex: '0', role: 'button' }, this.pickText, this.input);
    this.pick.insertAdjacentHTML('afterbegin', '<svg width="16" height="16" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 12.5V4M5.5 7.5L9 4l3.5 3.5M3 14.5h12"/></svg>');
    // the whole card takes a dropped file; this says so while no drawing is in
    this.dropHint = el('span', { class: 'small muted svg-drop-hint', text: 'or drop a file here', 'aria-hidden': 'true' });
    this.remove = el('button', { type: 'button', id: 'svg-lines-remove', class: 'link small', text: 'Remove SVG', hidden: true });
    this.info = el('p', { id: 'svg-lines-info', class: 'small muted' });
    this.shapeSwitch = el('input', { type: 'checkbox', role: 'switch', id: 'svg-outline-switch' });
    this.shapeRow = el('label', { class: 'switch-row', hidden: true, title: 'Cut this pattern to the red SVG shapes, leaving blue holes empty. Pattern ends meet the printed borders.' }, this.shapeSwitch,
      el('span', {}, el('strong', { text: 'Fill its shapes with this pattern' })));
    this.note = el('p', { id: 'svg-preview-note', class: 'small muted', hidden: true });
    // a drawing to try, for whoever has none: every colour the studio reads, in one file that can be opened to see how
    this.tryButton = el('button', { type: 'button', id: 'svg-sample-try', class: 'link small', text: 'use the sample drawing' });
    const download = el('a', { href: SAMPLE_SVG, download: 'filafabric-sample.svg', class: 'link small svg-sample-download', id: 'svg-sample-download',
      title: 'Example SVG with pattern areas, cutouts, solid shapes and printed lines.' });
    download.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 2.5v7M5 7l3 3 3-3M3 12.5h10"/></svg>';
    download.append('Download sample SVG');
    this.sample = el('div', { class: 'svg-sample small muted' },
      el('p', {}, 'or ', this.tryButton),
      el('p', {}, download));
    this.node = el('div', { class: 'svg-layer-control', 'aria-label': 'SVG import' },
      el('div', { class: 'svg-layer-actions' }, this.pick, this.dropHint, this.remove), this.sample, this.info, this.shapeRow, this.note);
    this.tryButton.addEventListener('click', async () => {
      try {
        const res = await fetch(SAMPLE_SVG);
        if (!res.ok) throw new Error(`${res.status}`);
        await host.importSvg(new File([await res.text()], 'filafabric-sample.svg', { type: 'image/svg+xml' }));
      } catch {
        host.toast('The sample drawing could not be loaded. Download it and import it instead.');
      }
    });

    this.input.addEventListener('change', (e) => { if (e.target.files[0]) void host.importSvg(e.target.files[0]); e.target.value = ''; });
    this.pick.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); this.input.click(); } });
    this.remove.addEventListener('click', () => host.removeSvg());
    this.shapeSwitch.addEventListener('change', () => host.setShapeOutline(this.shapeSwitch.checked));
    const node = this.node;
    node.addEventListener('dragover', (e) => { e.preventDefault(); node.classList.add('dragover'); });
    node.addEventListener('dragleave', () => node.classList.remove('dragover'));
    node.addEventListener('drop', (e) => { e.preventDefault(); node.classList.remove('dragover'); if (e.dataTransfer.files[0]) void host.importSvg(e.dataTransfer.files[0]); });
  }

  update() {
    const s = this.host.svg();
    const v = s.vector;
    this.info.textContent = v ? `${v.name} · ${fmt(v.width)} × ${fmt(v.height)} mm` : '';
    this.info.hidden = !v;
    this.pick.dataset.tip = v ? 'Replace the imported SVG drawing.' : 'Import an SVG drawing at its document size.';
    this.pick.setAttribute('aria-description', this.pick.dataset.tip);
    this.remove.hidden = !v;
    this.dropHint.hidden = !!v;
    this.sample.hidden = !!v;
    this.pickText.textContent = v ? 'Replace SVG' : 'Import SVG';
    // a design that draws the SVG itself has its own say about shapes; the others can be cut to them
    this.shapeRow.hidden = !(v && s.allowsOutline && !s.usesVector);
    this.shapeRow.classList.toggle('disabled', !s.hasShapes);
    this.shapeSwitch.disabled = !s.hasShapes;
    this.shapeSwitch.checked = !!s.outlineOn;
    this.note.hidden = !s.window;
    if (s.window) this.note.textContent = `Preview sample: ${fmt(s.window[0])} × ${fmt(s.window[1])} mm. Full SVG: ${fmt(v.width)} × ${fmt(v.height)} mm.`;
  }
}
